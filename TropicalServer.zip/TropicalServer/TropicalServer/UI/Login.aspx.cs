﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace TropicalServer.UI
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblerror.Visible = false;
            if (!IsPostBack)
            {
                if(Request.Cookies["username"] != null)
                {
                    usernametextbox.Text = Request.Cookies["username"].Value;
                }
                if (Request.Cookies["password"] != null)
                {
                    passwordtextbox.Attributes.Add("value", Request.Cookies["password"].Value);
                }
                if (Request.Cookies["username"] != null && Request.Cookies["password"] != null)
                {
                    cbRememberID.Checked = true;
                }
            }
        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            string sConn = "TropicalServer.Properties.Settings.TropicalServerConn";
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings[sConn];
            using (SqlConnection sqlCon = new SqlConnection(@"Initial Catalog=TropicalServer;Data Source= ROBERTS-HP;Integrated Security=true;"))
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand ("Select * from tblTropicalUser where UserID=@username and Password=@password", sqlCon);
                cmd.Parameters.AddWithValue("@username", usernametextbox.Text.Trim());
                cmd.Parameters.AddWithValue("@password", passwordtextbox.Text.Trim());
                SqlDataAdapter ver = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ver.Fill(dt);

                int count = cmd.ExecuteNonQuery();
                sqlCon.Close();

                if (dt.Rows.Count > 0)
                {
                    Session["username"] = usernametextbox.Text.Trim();                    
                    if (cbRememberID.Checked)
                    {
                        Response.Cookies["username"].Value = usernametextbox.Text;
                        Response.Cookies["password"].Value = passwordtextbox.Text;
                        Response.Cookies["username"].Expires = DateTime.Now.AddDays(15);
                        Response.Cookies["password"].Expires = DateTime.Now.AddDays(15);
                    } 
                    else
                    {
                        Response.Cookies["username"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["password"].Expires = DateTime.Now.AddDays(-1);
                    }
                    Response.Redirect("Products.aspx");
                }
                else
                {
                    lblerror.Visible = true;                    
                }
            }
        }
    }
}
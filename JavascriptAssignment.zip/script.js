// Code goes here

// part 1
console.log('Part 1');
function getDateInfo()
{
var today = new Date();
  var day = today.getDay();
  var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
  console.log("Today is : " + daylist[day] + ".");
  var hour = today.getHours();
  var minute = today.getMinutes();
  var second = today.getSeconds();
  var prepand = (hour >= 12)? " PM ":" AM ";
  hour = (hour >= 12)? hour - 12: hour;
  if (hour===0 && prepand===' PM ') 
  { 
  if (minute===0 && second===0)
  { 
  hour=12;
  prepand=' Noon';
  } 
  else
  { 
  hour=12;
  prepand=' PM';
  } 
  } 
  if (hour===0 && prepand===' AM ') 
  { 
  if (minute===0 && second===0)
  { 
  hour=12;
  prepand=' Midnight';
  } 
  else
  { 
  hour=12;
  prepand=' AM';
  } 
  } 
console.log("Current Time : "+hour + prepand + " : " + minute + " : " + second);
}
getDateInfo();

// part 2
console.log('Part 2');
  var currentDay = new Date(),
      day = currentDay.getDate(),
      month = currentDay.getMonth() + 1,
      year = currentDay.getFullYear();
console.log(day + "/" + month + "/" + year);

//part3
function multiply()
{
        num1 = document.getElementById("numberOne").value;
        num2 = document.getElementById("numberTwo").value;
        document.getElementById("result").innerHTML = num1 * num2;
}

function divide() 
{ 
        num1 = document.getElementById("numberOne").value;
        num2 = document.getElementById("numberTwo").value;
document.getElementById("result").innerHTML = num1 / num2;
}

// part 4
console.log('Part 4');
console.log(document.URL);

//part 5
console.log('Part 5');
function reverse_number(n)
{
	n = n + "";
	return n.split("").reverse().join("");
}
console.log(reverse_number(32243));

//part 6
console.log('Part 6');
function secondLowestGreatest(arr_num)
{
  arr_num.sort(function(x,y)
           {
           return x-y;
           });
  var uniqa = [arr_num[0]];
  var result = [];
  
  for(var j=1; j < arr_num.length; j++)
  {
    if(arr_num[j-1] !== arr_num[j])
    {
      uniqa.push(arr_num[j]);
    }
  }
    result.push(uniqa[1],uniqa[uniqa.length-2]);
  return result.join(',');
  }

console.log(secondLowestGreatest([1,2,3,4,5]));

//part 7
console.log('Part 7');
var range = function(startNum, endNum) 
{
  if (endNum - startNum === 2) 
  {
    return [startNum + 1];
  } 
  else 
  {
    var list = range(startNum, endNum - 1);
    list.push(endNum - 1);
    return list;
  }
};

console.log(range(2,9));

// part 8
console.log('Part 8');
function mergeSort(leftPart,rightPart) 
{
	var i = 0;
	var j = 0;
	var results = [];

	while (i < leftPart.length || j < rightPart.length) {
		if (i === leftPart.length) {
			results.push(rightPart[j]);
			j++;
		} 
      else if (j === rightPart.length || leftPart[i] <= rightPart[j]) {
			results.push(leftPart[i]);
			i++;
		} else {
			results.push(rightPart[j]);
			j++;
		}
	}
	return results;
}

console.log(mergeSort([1,3,4], [3,7,9]));

// part 9
console.log('Part 9');
let a=-5;
let b=-2;
let c=-6;
let d= 0;
let f=-1;
if (a>b && a>c && a>d && a>f)
{
    console.log(a);
}
else if (b>a && b>c && b>d && b>f)
{
    console.log(b);
}
else if (c>a && c>b && c>d && c>f)
{
    console.log(c);
}
else if (d>a && d>c && d>b && d>f)
{
    console.log(d);
}
else
{
    console.log(f);
}

//part10 
function is_nan(val)
        {
        return val !== val;
       }
console.log('Part 10');
console.log(is_nan(NaN));

console.log(is_nan('Robert'));

//part 11
function is_sameType(value1, value2) {
        if(is_nan(value1) || is_nan(value2)) {
         return is_nan(value1) === is_nan(value2);
        }
        return toString.call(value1) === toString.call(value2);
    }

function is_nan(val)
        {
        return val !== val;
       }
console.log('Part 11');
console.log(is_sameType('12', 100));
console.log(is_sameType('12', '100'));
console.log(is_sameType(12, 100));




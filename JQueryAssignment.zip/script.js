var test = JSON.parse(localStorage.getItem('sampleData'));
var d;
if(test === null){
    test = [100];}


    var fname = document.getElementById("firstname").value;
    var lname = document.getElementById('lastname').value;
    var eml = document.getElementById('email').value;
    var loc = document.getElementById('location').value;
    var phn = document.getElementById('phone').value;
    var communication = document.getElementById('communication').value;
    var permanent = document.getElementById('permanent').value;
    var english =document.getElementById('english').value;
    var science =document.getElementById('science').value;
    var computers =document.getElementById('computers').value;
    var hardware =document.getElementById('hardware').value;


// DRAG AND DROP


document.addEventListener('dragstart', function (event) {
    event.dataTransfer.setData('Text', event.target.innerHTML);
});


//REMOVING VALIDATION ERRORS
function dltObj() {
    if (document.getElementById("removee")) {
        document.querySelector("#removee").remove();
    }
}

//ON SUBMIT FUNCTION
function register(event) {

    var fname = document.getElementById("firstname").value;
    var lname = document.getElementById('lastname').value;
    var eml = document.getElementById('email').value;
    var loc = document.getElementById('location').value;
    var phn = document.getElementById('phone').value;
    var communication = document.getElementById('communication').value;
    var permanent = document.getElementById('permanent').value;
    var english =document.getElementById('english').value;
    var science =document.getElementById('science').value;
    var computers =document.getElementById('computers').value;
    var hardware =document.getElementById('hardware').value;

   var userobj = {
                    firstname: fname,
                    lastname: lname,
                    email: eml,
                    phone: phn,
                    location: loc,
                    address: {
                              communication: communication,
                              permanent: permanent
                              },
                    Marks: {
                            english: english,
                            science: science,
                            computers: computers,
                            hardware: hardware
                          },
                                 }

                        
                             //var test = JSON.parse(localStorage.getItem('userList'));
                             test.push(userobj);
                             localStorage.setItem('sampleData', JSON.stringify(test));
                             loctable();
    

    return true;
}

// displaying table
function loctable() 
{
  test = JSON.parse(localStorage.getItem('sampleData'));

    if (localStorage.sampleData) 
    {


        //  var rtobj = JSON.parse(localStorage.getItem('userList'));
        var htm = "<table class='classoftable' border='1' style='border-collapse:collapse;' cellpadding='5'>";


// DROPDOWN TO SELECT ROWS


    
            $("#dropdown").change(function () 
            {
              
              var dropDownSize = $("#dropdown").val();
                    htm = '';
                    jQuery('#data').html(htm);
                    htm += '<tr ><th  >Firstname</th><th >Lastname</th><th >Email</th><th >Location</th><th>phone</th><th>Communication</th><th >Permanent</th><th >Action 1</th><th >Action2</th><th >Action 3</th>'
                    for (var i = 0; i < dropDownSize; i++) {
                        htm += '<tr id="tr_' + i + '"><td contenteditable="true">' + test[i].firstname + '</td>';
                        htm += '<td contenteditable="true">' + test[i].lastname + '</td>';
                        htm += '<td contenteditable="true">' + test[i].email + '</td>';
                        htm += '<td contenteditable="true">' + test[i].location + '</td>';
                        htm += '<td contenteditable="true">' + test[i].phone + '</td>';
                        htm += '<td contenteditable="true">' + test[i].address.communication + '</td>';
                        htm += '<td contenteditable="true">' + test[i].address.permanent + '</td>';
                        htm += '<td ><a href="#" id="edit' + i + '" style="color: darkred">Edit</a></td>';
                        htm += '<td ><a href="#" id="view' + i + '" style="color: darkred">View</a></td>';
                        htm += '<td ><a href="#" id="delete' + i + '" style="color: darkred">Delete</a></td>';
                        htm += '</tr>';
                    }

                    htm += '</table>';
                    jQuery('#data').html(htm);
                    $(".classoftable").show();
                });
            
            $("#dropdown").change();

        }
   
    else {

        jQuery.ajax({
            "type": "GET",
            "url": "sampleData.json",
            "datatype": "JSON",
            "success": function (data) {
                localStorage.setItem("sampleData", JSON.stringify(data));
                $("#dropdown").ready();
            },
            "error": function () {
                alert('Error happened while making server request!!!');
            }
        });


    }

}
    //Search Box
/*$(document).ready(function(){
  $('#search').keyup(function()
  {
    searchTable($(this).val());
  });
  
  function searchTable(value)
    {
        var table = $('#data');
       $('#data tr').each(function( )
        {
                var found = false;
               $(this).each(function(){
                 if($(this).text().toLowerCase().indexOf(value.toLowerCase())>= 0)
                 if(found === true)$(row).show();
               });
                
            });
    }
  
});
*/
    

//EDIT BUTTON

$("#edit").on('click', function ()  {

  table.find('tr').each(function (i, el) {
        var $tds = $(this).find('td'),
            fname = $tds.eq(0).text(),
            lname = $tds.eq(1).text(),
            eml = $tds.eq(2).text();
            loc =  $tds.eq(3).text();
            phn =  $tds.eq(4).text();
            communication =  $tds.eq(5).text();
            permanent =  $tds.eq(6).text();
            english =  $tds.eq(7).text();
            science =  $tds.eq(8).text();
            computers =  $tds.eq(9).text();
            hardware =  $tds.eq(10).text();
        
    });
    
    var h = 4
    console.log(h);
    test[d] = { fname, lname, eml, loc, phn, communication, permanent, english, science, computers, hardware};
    localStorage.setItem('sampleData', test);
    $("#dropdown").change();
});


//VIEW BUTTON
$("#view").on('click', function (event) {

    event.preventDefault();


    var idSplit = jQuery(this).attr('id').split('_'),
        trId = 'tr_' + idSplit[1];
    d=idSplit[1];

    if (test[d] !== '') {
        htm += '<tr ><th >Firstname</th><th >Lastname</th><th >Email</th><th >Location</th><th>phone</th><th>Communication</th><th >Permanent</th><th>English</th><th>Science</th><th>Computers</th><th>Hardware</th>'
        htm += '<tr id="tr_' + i + '"><td >' + test[i].firstname + '</td>';
        htm += '<td contenteditable=true>' + test[i].lastname + '</td>';
        htm += '<td >' + test[i].email + '</td>';
        htm1 += '<td >' + test[d].location + '</td>';
        htm1 += '<td >' + test[d].phone + '</td>';
        htm1 += '<td >' + '<strong>Communication :</strong>' + test[d].address.communication + "<br>" + '<strong>Permanent:</strong>' + test[d].address.permanent + '</td>';
        htm1 += '<td >' + '<strong>English :</strong>' + test[d].marks.english + "<br>" + '<strong>Science:</strong>' + test[d].marks.science + "<br>" + '<strong>Computers:</strong>' + test[d].marks.computers +  '<strong>Hardware:</strong>' + test[d].marks.hardware +'</td>';
        htm1 += '</tr>';
        htm1 += '</table>';

        jQuery('#' + trId).after('<tr><td colspan="7">'+htm1+'</td></tr>');
        test[d] = '';
    }

    else {
        jQuery('#' + trId).next().toggle(htm1);
    }

});
//dragable functions
function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}


//DELETE BUTTON

